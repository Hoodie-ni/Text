package textExcel;

public class EmptyCell implements Cell{
	private String contents = "          ";
	public String abbreviatedCellText() {
		return contents;
	}
	public String fullCellText() {
		return "";
	}
}
