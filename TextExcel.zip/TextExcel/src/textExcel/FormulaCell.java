package textExcel;
import java.util.*;

public class FormulaCell extends RealCell{
	private String contents;
	private String result;
	private Spreadsheet sheet;
	
	public FormulaCell(String input, Spreadsheet sheet) {
		contents = input.substring(2,input.length() - 2);
		this.sheet = sheet;
	}
	public String fullCellText() {
		return "( " + contents + " )";
	}
	
	public String abbreviatedCellText() {
		return (getDoubleValue() + "          ").substring(0, 10);
	}
	
	public double getDoubleValue() {
		String[] splitEx = contents.split(" ");
		System.out.println(Arrays.toString(splitEx));
		result = splitEx[0];
		for (int i = 1; i < splitEx.length; i += 2) {
			//tests for "SUM ="
			if (splitEx[0].equalsIgnoreCase("SUM")) {
				String[] splitOp = splitEx[1].split("-");
				double total = Double.parseDouble((sheet.getCell(new SpreadsheetLocation(splitOp[0]))).abbreviatedCellText());
				for (char j = splitOp[0].charAt(0); j < splitOp[1].charAt(0); j++) {
					for (int k = Integer.parseInt(splitOp[0].substring(1)); k < Integer.parseInt(splitOp[1].substring(1)); k++) {
						total += Double.parseDouble((sheet.getCell(new SpreadsheetLocation(j + k + ""))).abbreviatedCellText());
					}
				}
				result = total + "";
			//tests for "AVG = "
			} else if (splitEx[0].equalsIgnoreCase("AVG")){
				String[] splitOp = splitEx[1].split("-");
				double total = 0;
				int nums = 0;
				result = sheet.getCell(new SpreadsheetLocation (splitOp[0])).abbreviatedCellText();
				for (int j = 0; j < 2; j++) {
					if (splitOp[j].charAt(0) <= 'Z') {
						char newChar = (char) (splitOp[j].charAt(0) + 32);
						splitOp[j] = newChar + splitOp[j].substring(1);
					}
				}
				for (char j = splitOp[0].charAt(0); j < splitOp[1].charAt(0); j++) {
					for (int k = Integer.parseInt(splitOp[0].substring(1)); k < Integer.parseInt(splitOp[1].substring(1)); k++) {
						total += Double.parseDouble((sheet.getCell(new SpreadsheetLocation(j + k + ""))).abbreviatedCellText());
						nums += 1;
					}
					result = total/nums + "";
				}
			//tests for arithmetic formulas
			} else {
				if ((splitEx[i-1].charAt(0) >= 'A') && (splitEx[i-1].charAt(0) <= 'Z') || ((splitEx[i-1].charAt(0)) >= 'a' && (splitEx[i-1].charAt(0) <= 'z'))) {
					if (splitEx[i - 1].charAt(0) > 'Z') {
						char newChar = (char) (splitEx[i-1].charAt(0) - 32);
						splitEx[i-1] = newChar + splitEx[i-1].substring(1);
					}
					splitEx[i-1] = ((sheet.getCell(new SpreadsheetLocation(splitEx[i - 1]))).abbreviatedCellText());
    			}
				if ((splitEx[i+1].charAt(0) >= 'A') && (splitEx[i+1].charAt(0) <= 'Z') || ((splitEx[i+1].charAt(0)) >= 'a' && (splitEx[i+1].charAt(0) <= 'z'))) {
					if (splitEx[i+1].charAt(0) > 'Z') {
						char newChar = (char) (splitEx[i+1].charAt(0) - 32);
						splitEx[i+1] = newChar + splitEx[i+1].substring(1);
					}
					splitEx[i+1] = ((sheet.getCell(new SpreadsheetLocation(splitEx[i + 1]))).abbreviatedCellText());
    			}
				if (splitEx[i].equals("/")) {
					splitEx[i + 1] = (Double.parseDouble(splitEx[i - 1]) / Double.parseDouble(splitEx[i + 1])) + "";
				} else if (splitEx[i].equals("*")) {
					splitEx[i + 1] = (Double.parseDouble(splitEx[i - 1]) * Double.parseDouble(splitEx[i + 1])) + ""; 
				} else if (splitEx[i].equals("+")) {
					splitEx[i + 1] = (Double.parseDouble(splitEx[i - 1]) + Double.parseDouble(splitEx[i + 1])) + "";
				} else if (splitEx[i].equals("-")) {
					splitEx[i + 1] = (Double.parseDouble(splitEx[i - 1]) - Double.parseDouble(splitEx[i + 1])) + "";
				}
				result = splitEx[splitEx.length - 1];
			}
		}
		return Double.parseDouble(result);
	}
	
	public void print(String yee) {
		System.out.println(yee);
	}
}
