package textExcel;

public class PercentCell extends RealCell {
	private String contents;
	private double decimal;
	public PercentCell(String input) {
		contents = input;
		decimal = Double.parseDouble(input.substring(0, input.length() - 1));
	}
	public String abbreviatedCellText() {
		String tempstring = contents;
		if (contents.contains(".")) {
			tempstring = contents.substring(0, contents.indexOf("."));
		}
		if (contents.length() > 9) {
			tempstring = contents.substring(0, 9);
		}
		tempstring += "%";
		for(int i = tempstring.length(); i < 10; i++) {
			tempstring += " ";
		}
		return tempstring;
	}
				
	public String fullCellText() {
		return decimal / 100 + "";
				
	}
	
	public double getDoubleValue() { 
		return decimal / 100;
	}
}
