package textExcel;

public abstract class RealCell implements Cell {
	private String contents;
	public String fullCellText() {
		return "\"" + contents + "\"";
	}
	
	public String abbreviatedCellText() {
		contents += "         ";
		return contents.substring(0, 9);
	}
	
	public double getDoubleValue() {
		return 0;
	}
}
