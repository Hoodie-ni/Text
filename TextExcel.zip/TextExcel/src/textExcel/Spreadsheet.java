package textExcel;

// Update this file with your own code.

public class Spreadsheet implements Grid
{
	private Cell[][] sheet = new Cell[12][20];
	@Override
	public String processCommand(String command) {
		String newString = command.toLowerCase();
		String[] splitCom = command.split(" ");
		if(splitCom[0].equalsIgnoreCase("clear")) {
			if (splitCom.length == 1) {
				clear();
			} else {
				Location loc = new SpreadsheetLocation(splitCom[1].toUpperCase());
				sheet[loc.getCol()][loc.getRow()] = new EmptyCell();
			}
			getGridText();
		} else {
			Location loc = new SpreadsheetLocation(splitCom[0].toUpperCase());
			if (splitCom.length == 1) {
				return getCell(loc).fullCellText();
			} else if (splitCom[1].equals("=")) {
				String assign = "";
				for (int i = 2; i < splitCom.length; i++) {
					if (i > 2) {
						assign += " ";
					}
					assign += splitCom[i];
				}
				//makes new cell and processes value if needed
				if (splitCom[2].equals("")) {
					sheet[loc.getCol()][loc.getRow()] = new EmptyCell();
				} else if (assign.contains("\"")) {
					sheet[loc.getCol()][loc.getRow()] = new TextCell(assign);
				} else if (assign.contains("%")) {
					sheet[loc.getCol()][loc.getRow()] = new PercentCell(assign);
				} else if (assign.contains("(")) {
					sheet[loc.getCol()][loc.getRow()] = new FormulaCell(assign, this);
//				} else if (assign.contains(".")) {
				} else {
					sheet[loc.getCol()][loc.getRow()] = new ValueCell(splitCom[2]);
				}
				getGridText();
			}
		} 
		return getGridText();
	}

	@Override
	public int getRows() {
		return sheet[0].length;
	}

	@Override
	public int getCols() {
		return sheet.length;
	}

	@Override
	public Cell getCell(Location loc) {
		return sheet[loc.getCol()][loc.getRow()];
	}

	@Override
	public String getGridText() {
		String grid = "";
		grid += "   |";
		//column headers
		for (char i = 'A'; i <= 'L'; i++) {
			grid += (i + "         |");
		}
		grid += "\n";
		for(int i = 1; i <= 20; i++) {
			//row headers
			grid += i;
			if (i < 10) {
				grid += " ";
			}
			grid += " |";
			//cell contents
//			for(int j = 0; j < sheet.length; j++) {
				for(char k = 'A'; k <= 'L'; k++) {
					grid += ((getCell(new SpreadsheetLocation(k + "" + i))).abbreviatedCellText() + "|");
				}
				grid += "\n";
				
		}
		return grid;
	}

	public Spreadsheet() {
		clear();
	}
	
	public void clear() {
		for (int i = 0; i < sheet.length; i++) {
			for (int j = 0; j < sheet[0].length; j++) {
				sheet[i][j] = new EmptyCell();
			}
		}
		System.out.println(getGridText());
	}
}


/*
 * public static int hailstoneLength(int n){
 * 		int length = 1;
 * 		int num = n;
 * 		while (num > 1) {
 * 			if (num % 2 == 0) {
 * 				num /= 2;
 * 			} else {
 * 				num = 3 * num + 1;
 * 			}
 * 			length++;
 * 		}
 * 		return length;
 * }
 */