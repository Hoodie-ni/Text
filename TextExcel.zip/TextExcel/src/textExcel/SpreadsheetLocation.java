package textExcel;

//Update this file with your own code.

public class SpreadsheetLocation implements Location {
    private int col;
    private int row;
    public int getRow() {
        return row;
    }

    @Override
    public int getCol() {
        return col;
    }
    
    public SpreadsheetLocation(String cellName) {
        // constructor
    	col = cellName.charAt(0) - 'A';
    	row = Integer.parseInt(cellName.substring(1)) - 1;
    }

}
