package textExcel;

public class TextCell implements Cell {
	private String contents = "";
	public TextCell(String text) {
		if (text.length() > 2) {
			contents = text.substring(1, text.length()-1);
		}
	}
	public String abbreviatedCellText() {
		String tempstring = contents + "          ";
		return tempstring.substring(0, 10);
	}
				
	public String fullCellText() {
		return "\"" + contents + "\"";
				
	}
	
}