//Vivian Kwan
//APCS 3rd
//February 25, 2020
//spreadsheet
package textExcel;

import java.io.FileNotFoundException;
import java.util.Scanner;

// Update this file with your own code.

public class TextExcel {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Welcome to Text Excel!");
		Spreadsheet sheet = new Spreadsheet();
		System.out.println("What would you like to do? ");
		String response = input.nextLine();
		while (!response.equalsIgnoreCase("quit")) {
			System.out.println(sheet.processCommand(response));
			System.out.println("What would you like to do? ");
			response = input.nextLine();
		}
		input.close();
	}
}
