package textExcel;

public class ValueCell extends RealCell {
	private String contents;
	public ValueCell(String num) {
		contents = num;
		if(contents.length() > 2) {
			if (contents.contains(".")) {
			while (contents.endsWith("0") && !(contents.charAt(contents.length() - 2) == '.')) {
//				while (contents.endsWith("0") && (contents.contains("."))) {
					contents = contents.substring(0, contents.length() - 1);
				}
			}
		}
		System.out.println(contents + ".");
	}
	public String fullCellText() {
		return contents;
	}
	
	public String abbreviatedCellText() {
		String tempcontents = contents;
		if(!(tempcontents.contains("."))) {
			tempcontents += ".0";
		}
		tempcontents += "         ";
		System.out.println(contents);
		return tempcontents.substring(0, 10);
	}
	
	public double doubleValue() {
		return Double.parseDouble(contents);
	}
	
}
